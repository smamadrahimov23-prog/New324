import asyncio
import glob
import html
import logging
import os
import re
import shutil
import tempfile
import uuid
from collections import OrderedDict

import yt_dlp
from aiohttp import web
from aiogram import BaseMiddleware, Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.client.telegram import TelegramAPIServer
from aiogram.enums import ChatMemberStatus
from aiogram.filters import CommandStart
from aiogram.types import (CallbackQuery, FSInputFile, InlineKeyboardButton,
                           InlineKeyboardMarkup, Message)
from shazamio import Shazam

# ===================== SOZLAMALAR =====================
BOT_TOKEN = os.getenv("BOT_TOKEN") or "8221540234:AAEArcN2GFEnyH3rWTZaD3G5HRVuF6NSauc"  # env bo'lsa o'shani oladi, bo'lmasa shu token
PORT = int(os.getenv("PORT", "10000"))          # Render PORT ni o'zi beradi (UptimeRobot uchun web-server)
CHANNEL = "@uzbek1ston_news"                    # majburiy obuna kanali
CHANNEL_URL = "https://t.me/uzbek1ston_news"
LOCAL_API_URL = os.getenv("LOCAL_API_URL")      # ixtiyoriy: http://localhost:8081 (2GB gacha fayl)
COOKIES_FILE = "cookies.txt"                    # ixtiyoriy: Instagram/YouTube uchun
MAX_UPLOAD_MB = 2000 if LOCAL_API_URL else 50
MAX_PARALLEL = 4                                # bir vaqtda nechta yuklash
# ======================================================

START_TEXT = (
    "👋✨ Salom men Izlovchibotman!\n\n"
    "💎 Mening xususiyatlarim bilan tanishing:\n\n"
    "• Qo'shiq matni, nomi yoki ijrochi ismi orqali musiqa topaman\n\n"
    "• Instagram, Youtube va Tik-Tokdan video va undagi musiqani yuklab beraman\n\n"
    "• Bundan tashqari men ovozli xabar, video va audiodagi musiqani "
    "to'liq shaklda topib beraman\n\n"
    "🚀 Qisqasi, izlash — mening ishim.\n\n"
    "👇 Video linkini yoki qo'shiq nomini yuboring!"
)
NOT_SUB_TEXT = (
    "❌ Siz obuna bo'lmagansiz!\n\n"
    "Botdan foydalanish uchun avval kanalga obuna bo'ling, "
    "so'ng «✅ Tekshirish» tugmasini bosing."
)

URL_RE = re.compile(r"https?://\S+")
SUPPORTED = re.compile(
    r"(instagram\.com|youtube\.com|youtu\.be|facebook\.com|fb\.watch|fb\.com|tiktok\.com)",
    re.I,
)

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("izlovchibot")

SEM = asyncio.Semaphore(MAX_PARALLEL)
CACHE: "OrderedDict[str, dict]" = OrderedDict()
_BOT_USERNAME = None


def cache_put(data: dict) -> str:
    key = uuid.uuid4().hex[:10]
    CACHE[key] = data
    while len(CACHE) > 3000:
        CACHE.popitem(last=False)
    return key


# ===================== OBUNA TEKSHIRUVI =====================
async def is_subscribed(bot: Bot, user_id: int) -> bool:
    try:
        m = await bot.get_chat_member(CHANNEL, user_id)
        return m.status in (
            ChatMemberStatus.MEMBER,
            ChatMemberStatus.ADMINISTRATOR,
            ChatMemberStatus.CREATOR,
        )
    except Exception as e:
        log.warning("Obuna tekshirishda xato (bot kanalda admin bo'lishi kerak): %s", e)
        return False


def sub_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📢 Kanalga obuna bo'lish", url=CHANNEL_URL)],
        [InlineKeyboardButton(text="✅ Tekshirish", callback_data="check_sub")],
    ])


class SubMiddleware(BaseMiddleware):
    async def __call__(self, handler, event, data):
        user = data.get("event_from_user")
        if user is None:
            return await handler(event, data)
        if isinstance(event, CallbackQuery) and event.data == "check_sub":
            return await handler(event, data)
        if await is_subscribed(data["bot"], user.id):
            return await handler(event, data)
        if isinstance(event, CallbackQuery):
            await event.answer()
            await event.message.answer(NOT_SUB_TEXT, reply_markup=sub_kb())
        else:
            await event.answer(NOT_SUB_TEXT, reply_markup=sub_kb())


# ===================== YUKLASH FUNKSIYALARI =====================
def _base_opts(outdir: str) -> dict:
    opts = {
        "outtmpl": f"{outdir}/%(id)s.%(ext)s",
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "concurrent_fragment_downloads": 4,
        "retries": 3,
    }
    if os.path.exists(COOKIES_FILE):
        opts["cookiefile"] = COOKIES_FILE
    return opts


def _first_file(outdir: str, pattern: str = "*"):
    files = [f for f in glob.glob(os.path.join(outdir, pattern)) if os.path.isfile(f)]
    return max(files, key=os.path.getsize) if files else None


def dl_video(url: str, outdir: str):
    """1080p gacha eng yaxshi sifat; fayl katta bo'lsa pastroq sifatga tushadi."""
    for h in (1080, 720, 480, 360):
        for f in glob.glob(os.path.join(outdir, "*")):
            os.remove(f)
        opts = _base_opts(outdir)
        opts.update({
            "format": f"bv*[height<={h}]+ba/b[height<={h}]/b",
            "merge_output_format": "mp4",
        })
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=True)
        if info and "entries" in info:
            info = info["entries"][0]
        path = _first_file(outdir)
        if path and os.path.getsize(path) <= MAX_UPLOAD_MB * 1024 * 1024:
            return path, info
    return None, None


def dl_audio(target: str, outdir: str):
    opts = _base_opts(outdir)
    opts.update({
        "format": "bestaudio/best",
        "postprocessors": [{
            "key": "FFmpegExtractAudio",
            "preferredcodec": "mp3",
            "preferredquality": "192",
        }],
    })
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(target, download=True)
    if info and "entries" in info:
        info = info["entries"][0]
    return _first_file(outdir, "*.mp3"), info


def yt_search(query: str, n: int = 10):
    opts = {"quiet": True, "no_warnings": True, "extract_flat": True}
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(f"ytsearch{n}:{query}", download=False)
    out = []
    for e in info.get("entries", []):
        if e and e.get("id"):
            out.append({
                "url": f"https://www.youtube.com/watch?v={e['id']}",
                "title": e.get("title") or "Noma'lum",
                "duration": e.get("duration") or 0,
            })
    return out


async def shazam_recognize(path: str):
    try:
        shazam = Shazam()
        fn = getattr(shazam, "recognize", None) or shazam.recognize_song
        out = await fn(path)
        track = out.get("track") if out else None
        if track:
            return track.get("title"), track.get("subtitle")
    except Exception as e:
        log.warning("Shazam xato: %s", e)
    return None


def fmt_dur(sec) -> str:
    sec = int(sec or 0)
    return f"{sec // 60}:{sec % 60:02d}"


async def bot_username(bot: Bot) -> str:
    global _BOT_USERNAME
    if not _BOT_USERNAME:
        _BOT_USERNAME = (await bot.get_me()).username
    return _BOT_USERNAME


async def send_mp3(bot: Bot, chat_id: int, path: str, title=None, artist=None):
    uname = await bot_username(bot)
    await bot.send_audio(
        chat_id,
        FSInputFile(path),
        title=title,
        performer=artist,
        caption=f"🎵 {html.escape(artist + ' — ' if artist else '')}{html.escape(title or '')}\n\n🤖 @{uname}",
    )


# ===================== HANDLERLAR =====================
dp = Dispatcher()
dp.message.middleware(SubMiddleware())
dp.callback_query.middleware(SubMiddleware())


@dp.message(CommandStart())
async def cmd_start(message: Message):
    await message.answer(START_TEXT)


@dp.callback_query(F.data == "check_sub")
async def cb_check(call: CallbackQuery, bot: Bot):
    if await is_subscribed(bot, call.from_user.id):
        await call.answer("✅ Rahmat!")
        await call.message.answer(START_TEXT)
    else:
        await call.answer("❌ Siz hali obuna bo'lmagansiz!", show_alert=True)


async def send_full_song(bot: Bot, chat_id: int, title: str, artist: str, workdir: str):
    query = f"{artist} - {title}" if artist else title
    async with SEM:
        path, info = await asyncio.to_thread(dl_audio, f"ytsearch1:{query}", workdir)
    if not path:
        await bot.send_message(chat_id, "😔 Qo'shiq topilmadi.")
        return
    await send_mp3(bot, chat_id, path, title, artist)


# ---- video linklar ----
async def handle_video(message: Message, url: str):
    status = await message.answer("⏳ Video yuklanmoqda...")
    workdir = tempfile.mkdtemp()
    try:
        async with SEM:
            path, info = await asyncio.to_thread(dl_video, url, workdir)
        if not path:
            await status.edit_text("😔 Videoni yuklab bo'lmadi yoki hajmi juda katta.")
            return
        key = cache_put({"url": url, "title": (info or {}).get("title")})
        kb = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="🎵 Qo'shiqni yuklab olish", callback_data=f"song:{key}")
        ]])
        uname = await bot_username(message.bot)
        title = html.escape((info or {}).get("title") or "")[:200]
        await message.answer_video(
            FSInputFile(path),
            caption=f"🎬 {title}\n\n🤖 @{uname}",
            reply_markup=kb,
            supports_streaming=True,
            width=(info or {}).get("width"),
            height=(info or {}).get("height"),
            duration=int((info or {}).get("duration") or 0) or None,
        )
        await status.delete()
    except Exception as e:
        log.exception("video xato")
        await status.edit_text("😔 Xatolik yuz berdi. Linkni tekshirib qayta urinib ko'ring.")
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


@dp.callback_query(F.data.startswith("song:"))
async def cb_song(call: CallbackQuery, bot: Bot):
    entry = CACHE.get(call.data.split(":", 1)[1])
    await call.answer()
    if not entry:
        await call.message.answer("⌛ Eskirgan so'rov. Linkni qayta yuboring.")
        return
    status = await call.message.answer("🔍 Qo'shiq qidirilmoqda...")
    workdir = tempfile.mkdtemp()
    try:
        # 1) videodan audioni ajratamiz
        async with SEM:
            audio, info = await asyncio.to_thread(dl_audio, entry["url"], workdir)
        if not audio:
            await status.edit_text("😔 Audioni ajratib bo'lmadi.")
            return
        # 2) Shazam bilan aniqlaymiz
        found = await shazam_recognize(audio)
        if found:
            title, artist = found
            await status.edit_text(f"✅ Topildi: {html.escape(artist or '')} — {html.escape(title or '')}")
            await send_full_song(bot, call.message.chat.id, title, artist, workdir + "_full")
        else:
            # Shazam topa olmasa, videodagi audioni o'zini yuboramiz
            await status.edit_text("ℹ️ Aniq qo'shiq topilmadi, videodagi audio yuborilmoqda...")
            await send_mp3(bot, call.message.chat.id, audio, (info or {}).get("title"), None)
    except Exception:
        log.exception("song xato")
        await status.edit_text("😔 Xatolik yuz berdi.")
    finally:
        shutil.rmtree(workdir, ignore_errors=True)
        shutil.rmtree(workdir + "_full", ignore_errors=True)


# ---- ovozli xabar / audio / video orqali musiqa topish ----
@dp.message(F.voice | F.audio | F.video | F.video_note | F.animation)
async def media_recognize(message: Message, bot: Bot):
    obj = message.voice or message.audio or message.video or message.video_note or message.animation
    if obj.file_size and obj.file_size > 20 * 1024 * 1024 and not LOCAL_API_URL:
        await message.answer("⚠️ Fayl 20MB dan katta. Kichikroq fayl yuboring.")
        return
    status = await message.answer("🔍 Musiqa aniqlanmoqda...")
    workdir = tempfile.mkdtemp()
    try:
        src = os.path.join(workdir, "input.bin")
        await bot.download(obj, destination=src)
        found = await shazam_recognize(src)
        if not found:
            await status.edit_text("😔 Musiqa aniqlanmadi. Aniqroq/uzunroq parcha yuboring.")
            return
        title, artist = found
        await status.edit_text(f"✅ Topildi: {html.escape(artist or '')} — {html.escape(title or '')}")
        await send_full_song(bot, message.chat.id, title, artist, workdir + "_full")
    except Exception:
        log.exception("media xato")
        await status.edit_text("😔 Xatolik yuz berdi.")
    finally:
        shutil.rmtree(workdir, ignore_errors=True)
        shutil.rmtree(workdir + "_full", ignore_errors=True)


# ---- matn: link yoki qo'shiq nomi ----
@dp.message(F.text)
async def on_text(message: Message):
    text = message.text.strip()
    m = URL_RE.search(text)
    if m:
        url = m.group(0)
        if SUPPORTED.search(url):
            await handle_video(message, url)
        else:
            await message.answer("⚠️ Bu link qo'llab-quvvatlanmaydi. Instagram, YouTube, TikTok yoki Facebook linkini yuboring.")
        return

    status = await message.answer("🔍 Qidirilmoqda...")
    try:
        async with SEM:
            results = await asyncio.to_thread(yt_search, text, 10)
        if not results:
            await status.edit_text("😔 Hech narsa topilmadi.")
            return
        key = cache_put({"results": results})
        lines = [f"{i}. {html.escape(r['title'][:60])} — {fmt_dur(r['duration'])}"
                 for i, r in enumerate(results, 1)]
        buttons = [InlineKeyboardButton(text=str(i), callback_data=f"pick:{key}:{i-1}")
                   for i in range(1, len(results) + 1)]
        rows = [buttons[i:i + 5] for i in range(0, len(buttons), 5)]
        await status.edit_text("🎧 Natijalar:\n\n" + "\n".join(lines),
                               reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    except Exception:
        log.exception("qidiruv xato")
        await status.edit_text("😔 Qidiruvda xatolik yuz berdi.")


@dp.callback_query(F.data.startswith("pick:"))
async def cb_pick(call: CallbackQuery, bot: Bot):
    _, key, idx = call.data.split(":")
    entry = CACHE.get(key)
    await call.answer()
    if not entry:
        await call.message.answer("⌛ Eskirgan so'rov. Qaytadan qidiring.")
        return
    r = entry["results"][int(idx)]
    status = await call.message.answer("⏳ Yuklanmoqda...")
    workdir = tempfile.mkdtemp()
    try:
        async with SEM:
            path, info = await asyncio.to_thread(dl_audio, r["url"], workdir)
        if not path:
            await status.edit_text("😔 Yuklab bo'lmadi.")
            return
        await send_mp3(bot, call.message.chat.id, path, r["title"], (info or {}).get("uploader"))
        await status.delete()
    except Exception:
        log.exception("pick xato")
        await status.edit_text("😔 Xatolik yuz berdi.")
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


async def health(request: web.Request) -> web.Response:
    return web.Response(text="OK")


async def start_web() -> web.AppRunner:
    """UptimeRobot pinglashi uchun oddiy web-server."""
    app = web.Application()
    app.router.add_get("/", health)
    app.router.add_get("/health", health)
    runner = web.AppRunner(app)
    await runner.setup()
    await web.TCPSite(runner, "0.0.0.0", PORT).start()
    log.info("Web-server %s portda ishga tushdi", PORT)
    return runner


async def main():
    if not BOT_TOKEN:
        raise SystemExit("BOT_TOKEN o'rnatilmagan! Render > Environment bo'limiga qo'shing.")
    runner = await start_web()          # 1) web-server (UptimeRobot uchun)
    session = None
    if LOCAL_API_URL:
        session = AiohttpSession(api=TelegramAPIServer.from_base(LOCAL_API_URL))
    bot = Bot(BOT_TOKEN, session=session,
              default=DefaultBotProperties(parse_mode="HTML"))
    try:
        await bot.delete_webhook(drop_pending_updates=True)
        await dp.start_polling(bot)     # 2) bot (polling) — ikkalasi bir vaqtda
    finally:
        await bot.session.close()
        await runner.cleanup()


if __name__ == "__main__":
    asyncio.run(main())
